# Project Description
# In this project you need to implement graph algorithms. You will be building a graph network.
# In addition, you will need to build a profession and title dictionary. After that you will need to
# code and implement test cases for graph algorithms like BFS, DFS, Dijkstra’s and strongly
# connected components. More details about these will be given below.
#  Project Package
# For this project, you will be given a few files that you need to work with. Those files include the
# one dataset files, two skeleton code files, and one python code file to run the test cases. The
# testing python script tells you how many test cases your code passed and failed.
#  Dataset

# For this project you will be using the imdb_network.csv. The required data is
# extracted and provided as CSV file.
# (1) Imdb_network.csv file
#  The dataset file includes the following attributes as columns.
# tconst – a unique identifier for each movie
# nconst – a unique identifier for each person
# primaryTitle – popular title that is used for promotions
# primaryName – name by which a person is often credited
# primaryProfession – top 3 professions of a person
#  Skeleton codes
# (1) Graph_creation.py
# This python skeleton code file has the functions defined for creating title, profession
# dictionary, adding nodes, edges and graphs. Detailed comments are provided on what
# you need to code and where to write the code
# (2) graph_algorithms.py
# This python skeleton code file needs to be used to implement the bfs, dfs, Dijkstra and
# kosaraju algorithms. Comments on what you need to do and “Need to Code” comments
# are provided. Read the comments carefully and complete the code.
#  Testing scripts
# A testing script named ‘graph_testcases.py’ is provided. You do not have to write
# any code in this file. This file has all the test case functions called. And you can run this
# file to check and test your code as running this file gives you how many test cases your
# code passed or what testcases your code failed.

# Project Instructions
# Graph_testcases.py:
# This Python file will execute your codes and check whether the provided test cases are
# passed or failed.
# Graph_creation.py
#  Start implementing the graph_creation.py file.
# This file will be used for creating two dictionaries and adding nodes, edges and creating
# graph.
# This file contains a function _create_title_dict () where you will need to create a
# dictionary. The key values will be the nconst (of actor or director) and the
# values field will be a list of movies (primaryTitle’s) the actor or director is involved in.
#  In the _create_profession_dict () you will need to create a dictionary where keys will be
# nconst and the values will be corresponding actor or director. An example dictionary is
# mentioned as a comment in the code.
#  In the movie network class of the same file you will need to implement 3 functions
#  In the add_node () function you will need to add nodes to the graph. The nodes will be
# nconst values. It takes node as argument.
#  In the add_edge () function you will need to add edges to the graph. It takes node1,
# node 2, nconst_ar_dr, and weight as arguments. Node 1 and Node 2 are the two end
# nodes for the edge, nconst_ar_dr is profession dictionary you constructed above, and
# weight is the number of common movie titles between the two nodes. The result should
# be a dictionary where key is nconst (Node 1) and value is again a dictionary with key
# representing other nconst (Node 2) and weight as the value.
#  Before adding Edge weights you must follow the below Instructions:
# 1) The weight of the edges should be greater than 2
# 2) Node 1-> Node 2 relation can be that of a director -> actor, but not that of an actor ->
# director. Again, detailed example of this is provided as a comment in the code of
# get_graph function.
# 3) Bi-directional edges should be added if both Node1 and Node2 are of same category
# either both are actors, or both are directors. For example: If Node 1 is of actor, then
# Node 2 should also be of actor and if Node 1 is of director, then Node 2 should also be
# of director. More details are provided as comments in the code.
#  In create_graph () function you need to create a graph by following the proper edge
# weights and node conventions as mentioned. More details are provided as comments in
# the code. 


# Below is graph_creation.py. Please go through as rewrite based on the instructions given


# def __init__(self, csv_path):
#     self.df = pd.read_csv(csv_path)
#     self.title_dict = self._create_title_dict()
#     self.profession_dict = self._create_profession_dict()

# def _create_title_dict(self):
#     title_dict = {}
#     for index, row in self.df.iterrows():
#         nconst = row["nconst"]
#         title = row["primaryTitle"]
#         if nconst in title_dict:
#             title_dict[nconst].append(title)
#         else:
#             title_dict[nconst] = [title]
#     return title_dict

# def _create_profession_dict(self):
#     profession_dict = {}
#     for index, row in self.df.iterrows():
#         nconst = row["nconst"]
#         profession = row["primaryProfession"].split(",")[0]
#         profession_dict[nconst] = profession
#     return profession_dict



# #Graph Network Creation
# class MovieNetwork:
#     def __init__(self, name_movie_dict, nconst_ar_dr):
#         self.graph = {} #graph dictionary initialization
#         self.name_movie_dict = name_movie_dict #name_movie_dict is nothing but "title_dict" dictionary refer to above example in TitleDictionary.
#         self.nconst_ar_dr = nconst_ar_dr #it is "profession_dict" dictionary refer to above example in TitleDictionary.


#     def add_node(self, node):
#         #write code to add node to the graph (dictionary data-structure)

#     def add_edge(self, node1, node2, nconst_ar_dr, weight=1):
#         #node 1, node 2: nconst id's
#         #nconst_ar_dr is nothing but "profession_dict" dictionary refer to above example in TitleDictionary.
#         #weight is number of common movie titles exists in node1 and node2
#         #Before adding Edge weights you must follow the below Instructions:
#             #1. consider only the node1->node2 connection or edge, only if node1 and node2 have more than 2 movies in common.
#             #2. Let node1="actor" and node2="director" then node1->node2 edge should not be taken implies {actor:{director:6}} must not be taken.
#                 # But node2->node1 should be taken implies {director:{actor:6}} must be taken.
#             #3. if node1 and node2 are assigned with both actors or directors then bi-directional edge must be added implies
#                 #{actor1:{actor2:4}} and {actor2:{actor1:4}} or {director1:{director2:7}} and {director2:{director1:7}} both ways are true
#                 #and must consider in dictionary.
#         #write code to add edge to the graph implies add weight between node1 and node 2
#         #Example weight assignment looks like:
#         # {'nm1172995': {'nm0962553': 7}} here the weight 7 is nothing but the number of common
#         #movies between two persons either actor/director (nm1172995 and nm0962553)

#     def create_graph(self):
#         #By following the above conditions create a graph (use only dictionary datastructure: self.graph)
#         #example graph looks like:
#           # {'nm0962553': {'nm8630849': 3,
#           #     'nm1172995': 7,
#           #     'nm8742830': 16,
#           #     'nm6225202': 4,
#           #     'nm4366294': 4},
#           #    'nm8630849': {},
#           #    'nm1172995': {'nm0962553': 7},
#           #    'nm8742830': {'nm0962553': 16},
#           #    'nm6225202': {}}

#         return graph


# class MovieNetwork:
#     def __init__(self):
#     self.graph = {}

# def add_node(self, node):
#     if node not in self.graph:
#         self.graph[node] = {}

# def add_edge(self, node1, node2, profession_dict, weight):
#     profession1 = profession_dict[node1]
#     profession2 = profession_dict[node2]
#     if profession1 == profession2:
#         if profession1 == "actor" or profession1 == "actress":
#             self.graph[node1][node2] = weight
#             self.graph[node2][node1] = weight
#         elif profession1 == "director":
#             if node1 < node2:
#                 self.graph[node1][node2] = weight
#             else:
#                 self.graph[node2][node1] = weight

# def create_graph(self):
#     for node1 in self.title_dict.keys():
#         self.add_node(node1)
#         for node2 in self.title_dict.keys():
#             if node1 != node2:
#                 common_titles = list(set(self.title_dict[node1]).intersection(self.title_dict[node2]))
#                 if len(common_titles) > 2:
#                     weight = len(common_titles)
#                     self.add_edge(node1, node2, self.profession_dict, weight)



import pandas as pd

import pandas as pd

class TitleDictionary:
    def __init__(self, csv_path):
        self.df = pd.read_csv(csv_path)
        self.title_dict = self._create_title_dict()
        self.profession_dict = self._create_profession_dict()

    def _create_title_dict(self):
        title_dict = {}
        for _, row in self.df.iterrows():
            nconst = row['nconst']
            title = row['primaryTitle']
            if nconst not in title_dict:
                title_dict[nconst] = [title]
            else:
                title_dict[nconst].append(title)
        return title_dict

    def _create_profession_dict(self):
        profession_dict = {}
        for _, row in self.df.iterrows():
            nconst = row['nconst']
            profession = row['primaryProfession'].split(',')[0]
            profession_dict[nconst] = profession
        return profession_dict


class MovieNetwork:
    def __init__(self, name_movie_dict, nconst_ar_dr):
        self.graph = {} # graph dictionary initialization
        self.name_movie_dict = name_movie_dict # name_movie_dict is nothing but "title_dict" dictionary refer to above example in TitleDictionary.
        self.nconst_ar_dr = nconst_ar_dr # it is "profession_dict" dictionary refer to above example in TitleDictionary.

    def add_node(self, node):
        # write code to add node to the graph (dictionary data-structure)
        if node not in self.graph:
            self.graph[node] = {}

    def add_edge(self, node1, node2, nconst_ar_dr, weight=1):
        # node 1, node 2: nconst id's
        # nconst_ar_dr is nothing but "profession_dict" dictionary refer to above example in TitleDictionary.
        # weight is the number of common movie titles that exist in node1 and node2
        # Before adding Edge weights you must follow the below Instructions:
        #   1. consider only the node1->node2 connection or edge, only if node1 and node2 have more than 2 movies in common.
        #   2. Let node1="actor" and node2="director" then node1->node2 edge should not be taken implies {actor:{director:6}} must not be taken.
        #      But node2->node1 should be taken implies {director:{actor:6}} must be taken.
        #   3. if node1 and node2 are assigned with both actors or directors then bi-directional edge must be added implies
        #      {actor1:{actor2:4}} and {actor2:{actor1:4}} or...
        if node1 not in self.graph:
            self.add_node(node1)
        if node2 not in self.graph:
            self.add_node(node2)

        if node1 != node2:
            common_movies = set(self.name_movie_dict[node1]).intersection(set(self.name_movie_dict[node2]))
            if len(common_movies) > 2:
                profession1 = nconst_ar_dr[node1]
                profession2 = nconst_ar_dr[node2]
                if profession1 != profession2:
                    if profession1 == 'actor':
                        self.graph[node1][node2] = len(common_movies)
                    elif profession2 == 'actor':
                        self.graph[node2][node1] = len(common_movies)
                elif profession1 == profession2:
                    self.graph[node1][node2] = len(common_movies)
                    self.graph[node2][node1] = len(common_movies)

    def create_graph(self):
        # create a graph by following the proper edge weights and node conventions as mentioned.
        # The graph should be a dictionary with the following structure:
        # key: nconst (Node 1)
        # value: dictionary
        #        key: nconst (Node 2)
        #        value: weight
        for nconst1 in self.name_movie_dict.keys():
            for nconst2 in self.name_movie_dict.keys():
                if nconst1 != nconst2:
                    self.add_edge(nconst1, nconst2, self.nconst_ar_dr)

        return self.graph






# class MovieNetwork:
#     def __init__(self, name_movie_dict, nconst_ar_dr):
#         self.graph = {}
#         self.name_movie_dict = name_movie_dict
#         self.nconst_ar_dr = nconst_ar_dr

#     def add_node(self, node):
#         # Add a node to the graph
#         if node not in self.graph:
#             self.graph[node] = {}

#     def add_edge(self, node1, node2, nconst_ar_dr, weight=1):
#         # Add an edge to the graph
#         if node1 not in self.graph:
#             self.graph[node1] = {}
#         if node2 not in self.graph:
#             self.graph[node2] = {}

#         # Check if node1 and node2 are actors or directors
#         profession1 = nconst_ar_dr[node1]
#         profession2 = nconst_ar_dr[node2]
#         if profession1 != profession2:
#             if profession1 == 'actor' and profession2 == 'director':
#                 return
#             elif profession1 == 'director' and profession2 == 'actor':
#                 self.graph[node2][node1] = weight
#             else:
#                 return

#         # Check if the weight of the edge is greater than 2
#         if weight <= 2:
#             return

#         # Add bi-directional edges if both nodes are of the same profession
#         if profession1 == profession2:
#             self.graph[node1][node2] = weight
#             self.graph[node2][node1] = weight

#     def create_graph(self):
#         # Create the graph by adding nodes and edges to the graph
#         for node in self.name_movie_dict.keys():
#             self.add_node(node)

#         for node1 in self.name_movie_dict.keys():
#             for node2 in self.name_movie_dict.keys():
#                 if node1 == node2:
#                     continue
#                 # Calculate the number of common movies between node1 and node2
#                 common_movies = set(self.name_movie_dict[node1]).intersection(set(self.name_movie_dict[node2]))
#                 weight = len(common_movies)
#                 self.add_edge(node1, node2, self.nconst_ar_dr, weight)

#         return self.graph







#### START OF ROUND TWO########################


# class TitleDictionary:
#     def __init__(self, csv_path):
#         self.df = pd.read_csv(csv_path)
#         self.title_dict = self._create_title_dict()
#         self.profession_dict = self._create_profession_dict()

#     def _create_title_dict(self):
#         # Dictionary structure:
#         # key: nconst
#         # value: list of movie_names(primaryTitle’s) actors/directors involved in
#         # Create a dictionary in the format:
#         # {nconst:[movie_names actors/directors involved in], here the actor/director is determined by id: nconst}
#         title_dict = {}
#         for _, row in self.df.iterrows():
#             nconst = row['nconst']
#             title = row['primaryTitle']
#             if nconst not in title_dict:
#                 title_dict[nconst] = [title]
#             else:
#                 title_dict[nconst].append(title)
#         return title_dict

#     def _create_profession_dict(self):
#         # Dictionary structure:
#         # key: nconst
#         # value: profession
#         # Create a dictionary in the format:
#         # {nconst: profession}
#         profession_dict = {}
#         for _, row in self.df.iterrows():
#             nconst = row['nconst']
#             profession = row['primaryProfession'].split(',')[0]  # Taking the first profession
#             profession_dict[nconst] = profession
#         return profession_dict


# class MovieNetwork:
#     def __init__(self, name_movie_dict, nconst_ar_dr):
#         self.graph = {}
#         self.name_movie_dict = name_movie_dict
#         self.nconst_ar_dr = nconst_ar_dr

#     def add_node(self, node):
#         # Adding node to the graph
#         if node not in self.graph:
#             self.graph[node] = {}

#     def add_edge(self, node1, node2, nconst_ar_dr, weight=1):
#         # Adding edge to the graph
#         if node1 == node2:
#             return
#         profession1 = nconst_ar_dr[node1]
#         profession2 = nconst_ar_dr[node2]
#         if profession1 != profession2:
#             return
#         common_movies = set(self.name_movie_dict[node1]).intersection(set(self.name_movie_dict[node2]))
#         if len(common_movies) <= 2:
#             return
#         if profession1 == "actor":
#             self.graph.setdefault(node2, {}).setdefault(node1, 0)
#             self.graph[node2][node1] += weight
#         else:
#             self.graph.setdefault(node1, {}).setdefault(node2, 0)
#             self.graph[node1][node2] += weight
#         if profession1 == profession2:
#             if profession1 == "actor":
#                 self.graph.setdefault(node1, {}).setdefault(node2, 0)
#                 self.graph[node1][node2] += weight
#             else:
#                 self.graph.setdefault(node2, {}).setdefault(node1, 0)
#                 self.graph[node2][node1] += weight

#     def create_graph(self):
#         # Creating graph by adding nodes and edges to the graph
#         for node in self.name_movie_dict.keys():
#             self.add_node(node)
#         for node1 in self.name_movie_dict.keys():
#             for node2 in self.name_movie_dict.keys():
#                 if node1 == node2:
#                     continue
#                 self.add_edge(node1, node2, self.nconst_ar_dr)
#         return self.graph

#### END ROUND TWO########################



#### ROUND ONE########################
# class TitleDictionary:
#     def __init__(self, csv_path):
#         self.df = pd.read_csv(csv_path)
#         self.title_dict = self._create_title_dict()
#         self.profession_dict = self._create_profession_dict()

#     def _create_title_dict(self):
#         # Dictionary structure:
#         # key: nconst
#         # value: list of movie_names(primaryTitle's) actors/directors involved in
#         # Create a dictionary in the format:
#         # {nconst:[movie_names actors/directors involved in], here the actor/director is determined by id: nconst}
#         title_dict = {}
#         for _, row in self.df.iterrows():
#             nconst = row['nconst']
#             title = row['primaryTitle']
#             if nconst not in title_dict:
#                 title_dict[nconst] = [title]
#             else:
#                 title_dict[nconst].append(title)
#         return title_dict

#     def _create_profession_dict(self):
#         # Dictionary structure:
#         # key: nconst
#         # value: profession
#         # Create a dictionary in the format:
#         # {nconst: profession}
#         profession_dict = {}
#         for _, row in self.df.iterrows():
#             nconst = row['nconst']
#             profession = row['primaryProfession'].split(',')[0]  # Taking the first profession
#             profession_dict[nconst] = profession
#         return profession_dict



# class MovieNetwork:
#     def __init__(self, name_movie_dict, nconst_ar_dr):
#         self.graph = {}
#         self.name_movie_dict = name_movie_dict
#         self.nconst_ar_dr = nconst_ar_dr

#     def add_node(self, node):
#         if node not in self.graph:
#             self.graph[node] = {}

#     def add_edge(self, node1, node2, nconst_ar_dr, weight=1):
#         if node1 == node2:
#             return
#         if node1 in self.graph and node2 in self.graph:
#             profession1 = nconst_ar_dr[node1]
#             profession2 = nconst_ar_dr[node2]
#             common_movies = set(self.name_movie_dict[node1]) & set(self.name_movie_dict[node2])
#             if len(common_movies) > 2 and profession1 != profession2:
#                 if profession1 == 'actor' and profession2 == 'director':
#                     if node2 not in self.graph[node1]:
#                         self.graph[node1][node2] = weight
#                 elif profession1 == 'director' and profession2 == 'actor':
#                     if node1 not in self.graph[node2]:
#                         self.graph[node2][node1] = weight
#                 else:
#                     if node2 not in self.graph[node1]:
#                         self.graph[node1][node2] = weight
#                     if node1 not in self.graph[node2]:
#                         self.graph[node2][node1] = weight

#     def create_graph(self):
#         for node1 in self.name_movie_dict.keys():
#             self.add_node(node1)
#             for node2 in self.name_movie_dict.keys():
#                 if node1 != node2:
#                     self.add_node(node2)
#                     self.add_edge(node1, node2, self.nconst_ar_dr, len(set(self.name_movie_dict[node1]) & set(self.name_movie_dict[node2])))

#         return self.graph
#### END OF ROUND ONE########################









# class MovieNetwork:
#     def __init__(self, name_movie_dict, nconst_ar_dr):
#         self.graph = {}
#         self.name_movie_dict = name_movie_dict
#         self.nconst_ar_dr = nconst_ar_dr

#     def add_node(self, node):
#         # Add node to the graph
#         if node not in self.graph:
#             self.graph[node] = {}

#     def add_edge(self, node1, node2, nconst_ar_dr, weight=1):
#         # Add edge to the graph
#         if node1 not in self.graph:
#             self.graph[node1] = {}

#         if node2 not in self.graph:
#             self.graph[node2] = {}

#         # Count number of common movie titles between node1 and node2
#         common_movies = set(self.name_movie_dict[node1]).intersection(set(self.name_movie_dict[node2]))

#         # Check if node1 and node2 have more than 2 movies in common
#         if len(common_movies) > 2:
#             # Check if node1 is an actor and node2 is a director
#             if nconst_ar_dr[node1] == 'actor' and nconst_ar_dr[node2] == 'director':
#                 # Do not add node1 -> node2 edge
#                 pass
#             else:
#                 # Add node1 -> node2 edge
#                 self.graph[node1][node2] = len(common_movies)

#             # Check if node1 is a director and node2 is an actor
#             if nconst_ar_dr[node1] == 'director' and nconst_ar_dr[node2] == 'actor':
#                 # Add node2 -> node1 edge
#                 self.graph[node2][node1] = len(common_movies)

#             # Check if node1 and node2 have the same profession (actor or director)
#             if nconst_ar_dr[node1] == nconst_ar_dr[node2]:
#                 # Add bi-directional edge
#                 self.graph[node1][node2] = len(common_movies)
#                 self.graph[node2][node1] = len(common_movies)

#     def create_graph(self):
#         # Create graph
#         for node in self.name_movie_dict.keys():
#             self.add_node(node)

#         for node1 in self.name_movie_dict.keys():
#             for node2 in self.name_movie_dict.keys():
#                 if node1 == node2:
#                     continue
#                 self.add_edge(node1, node2, self.nconst_ar_dr)
