# Project Description
# In this project you need to implement graph algorithms. You will be building a graph network.
# In addition, you will need to build a profession and title dictionary. After that you will need to
# code and implement test cases for graph algorithms like BFS, DFS, Dijkstra’s and strongly
# connected components. More details about these will be given below.
#  Project Package
# For this project, you will be given a few files that you need to work with. Those files include the
# one dataset files, two skeleton code files, and one python code file to run the test cases. The
# testing python script tells you how many test cases your code passed and failed.
#  Dataset

# For this project you will be using the imdb_network.csv. The required data is
# extracted and provided as CSV file.
# (1) Imdb_network.csv file
#  The dataset file includes the following attributes as columns.
# tconst – a unique identifier for each movie
# nconst – a unique identifier for each person
# primaryTitle – popular title that is used for promotions
# primaryName – name by which a person is often credited
# primaryProfession – top 3 professions of a person
#  Skeleton codes
# (1) Graph_creation.py
# This python skeleton code file has the functions defined for creating title, profession
# dictionary, adding nodes, edges and graphs. Detailed comments are provided on what
# you need to code and where to write the code
# (2) graph_algorithms.py
# This python skeleton code file needs to be used to implement the bfs, dfs, Dijkstra and
# kosaraju algorithms. Comments on what you need to do and “Need to Code” comments
# are provided. Read the comments carefully and complete the code.
#  Testing scripts
# A testing script named ‘graph_testcases.py’ is provided. You do not have to write
# any code in this file. This file has all the test case functions called. And you can run this
# file to check and test your code as running this file gives you how many test cases your
# code passed or what testcases your code failed.

# Project Instructions
# Graph_testcases.py:
# This Python file will execute your codes and check whether the provided test cases are
# passed or failed.
# Graph_creation.py
#  Start implementing the graph_creation.py file.
# This file will be used for creating two dictionaries and adding nodes, edges and creating
# graph.
# This file contains a function _create_title_dict () where you will need to create a
# dictionary. The key values will be the nconst (of actor or director) and the
# values field will be a list of movies (primaryTitle’s) the actor or director is involved in.
#  In the _create_profession_dict () you will need to create a dictionary where keys will be
# nconst and the values will be corresponding actor or director. An example dictionary is
# mentioned as a comment in the code.
#  In the movie network class of the same file you will need to implement 3 functions
#  In the add_node () function you will need to add nodes to the graph. The nodes will be
# nconst values. It takes node as argument.
#  In the add_edge () function you will need to add edges to the graph. It takes node1,
# node 2, nconst_ar_dr, and weight as arguments. Node 1 and Node 2 are the two end
# nodes for the edge, nconst_ar_dr is profession dictionary you constructed above, and
# weight is the number of common movie titles between the two nodes. The result should
# be a dictionary where key is nconst (Node 1) and value is again a dictionary with key
# representing other nconst (Node 2) and weight as the value.
#  Before adding Edge weights you must follow the below Instructions:
# 1) The weight of the edges should be greater than 2
# 2) Node 1-> Node 2 relation can be that of a director -> actor, but not that of an actor ->
# director. Again, detailed example of this is provided as a comment in the code of
# get_graph function.
# 3) Bi-directional edges should be added if both Node1 and Node2 are of same category
# either both are actors, or both are directors. For example: If Node 1 is of actor, then
# Node 2 should also be of actor and if Node 1 is of director, then Node 2 should also be
# of director. More details are provided as comments in the code.
#  In create_graph () function you need to create a graph by following the proper edge
# weights and node conventions as mentioned. More details are provided as comments in
# the code. 


import csv
import json
from graph_creation import TitleDictionary, MovieNetwork
from graph_algorithms import bfs, dfs, dijkstra, kosaraju

with open("Graph_Output.json", "r") as file:
    data = json.load(file)

total=0
f=0

td = TitleDictionary('imdb_network.csv')
nconst_title = td.title_dict
nconst_ar_dr = td.profession_dict

movie_network = MovieNetwork(nconst_title, nconst_ar_dr)
graph = movie_network.create_graph()

def dictionary_test():
    global total
    global f
    if(data["dictionary_test"] == nconst_title):
        print("\n{nconst_title} Dictionary Test Passed")
    else:
        print("{nconst : title} mapping is Mismatched")
        f+=1
    total+=1

    return nconst_title

def movie_network_test():
    global total
    global f
    if(data["movie_network_test"] == graph):
        print("\nMovie Network is Successfully created")
    else:
        print("\nMovie Network is Mismatched")
        f+=1
    total+=1

    return graph

def testcase_1_1():
    global total
    global f
    testcase_1_1 = bfs(graph, "nm0465106")
    if(len(set(data["testcase_1_1"])-set(testcase_1_1))!=0):
        print("\nTestCase 1_1 Passed")
    else:
        print("\nTestCase 1_1 failed")
        f+=1
    total+=1

    return testcase_1_1

def testcase_1_2():
    global total
    global f
    testcase_1_2 = bfs(graph, "nm5822910", "nm5665539")
    if(data["testcase_1_2"]==testcase_1_2):
        print("\nTestCase 1_2 Passed")
    else:
        print("\nTestCase 1_2 failed")
        f+=1
    total+=1

    return testcase_1_2

def testcase_1_3():
    global total
    global f
    testcase_1_3 = bfs(graph, "nm5822910", "nm5775539")
    if(data["testcase_1_3"]==testcase_1_3):
        print("\nTestCase 1_3 Passed")
    else:
        print("\nTestCase 1_3 failed")
        f+=1
    total+=1

    return testcase_1_3

def testcase_2_1():
    global total
    global f
    testcase_2_1 = dfs(graph, "nm0465106")
    if(len(set(data["testcase_2_1"])-set(testcase_2_1))!=0):
        print("\nTestCase 2_1 Passed")
    else:
        print("\nTestCase 2_1 failed")
        f+=1
    total+=1

    return testcase_2_1

def testcase_2_2():
    global total
    global f
    testcase_2_2 = dfs(graph, "nm5822910", search_node="nm5665539")
    if(data["testcase_2_2"]==testcase_2_2):
        print("\nTestCase 2_2 Passed")
    else:
        print("\nTestCase 2_2 failed")
        f+=1
    total+=1

    return testcase_2_2

def testcase_2_3():
    global total
    global f
    testcase_2_3 = dfs(graph, "nm5822910", search_node="nm5694296")
    if(data["testcase_2_3"]==testcase_2_3):
        print("\nTestCase 2_3 Passed")
    else:
        print("\nTestCase 2_3 failed")
        f+=1
    total+=1

    return testcase_2_3

def testcase_3():
    global total
    global f
    testcase_3 = dijkstra(graph, "nm4556923", "nm5822910")
    if(data["testcase_3"][0]==testcase_3[0] and data["testcase_3"][1]==testcase_3[1] and data["testcase_3"][2]==testcase_3[2]):
        print("\nTestCase 3 Passed")
    else:
        if(data["testcase_3"][0]==testcase_3[0]):
            print("\nYour path for TestCase 3 is passed")
        else:
            print("\nYour path for TestCase 3 is InCorrect")
        if(data["testcase_3"][1]==testcase_3[1]):
            print("\nYour Sum of minimum distances for TestCase 3 is Correct")
        else:
            print("\nYour Sum of minimum distances for TestCase 3 is InCorrect")
        if(data["testcase_3"][2]==testcase_3[2]):
            print("\nYour Hop count from start node to end node for TestCase 3 is Correct")
        else:
            print("\nYour Hop count from start node to end node for TestCase 3 is InCorrect")

        f+=1
    total+=1

    return testcase_3

def testcase_4():
    global total
    global f
    testcase_4 = kosaraju(graph)
    if(len(data["testcase_4"])==len(testcase_4)):
        print("\nTestCase 4 Passed")
    else:
        print("\nTotal number of strongly connected components for TestCase 4 is InCorrect")
        f+=1
    total+=1

    return testcase_4

testcase = {}

testcase['dictionary_test'] = dictionary_test()
testcase['movie_network_test'] = movie_network_test()
testcase['testcase_1_1'] = testcase_1_1()
testcase['testcase_1_2'] = testcase_1_2()
testcase['testcase_1_3'] = testcase_1_3()
testcase['testcase_2_1'] = testcase_2_1()
testcase['testcase_2_2'] = testcase_2_2()
testcase['testcase_2_3'] = testcase_2_3()
testcase['testcase_3'] = testcase_3()
testcase['testcase_4'] = testcase_4()

print("\n\nTotal Test Cases Passed : {}\nTotal Test Cases Failed : {}".format(total-f,f))
